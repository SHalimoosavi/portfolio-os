/* SAYANJALI NEXUS — Founder OS — interactions */
(() => {
  'use strict';

  // ===== Loader =====
  window.addEventListener('load', () => {
    const l = document.getElementById('loader');
    if (l) setTimeout(() => l.classList.add('done'), 1100);
  });

  // ===== Mobile nav =====
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => links.classList.toggle('open'));
    links.querySelectorAll('a').forEach(a => a.addEventListener('click', () => links.classList.remove('open')));
  }

  // ===== Cursor glow (desktop only) =====
  if (matchMedia('(pointer:fine)').matches) {
    const glow = document.createElement('div');
    glow.className = 'cursor-glow';
    document.body.appendChild(glow);
    let x = innerWidth / 2, y = innerHeight / 2, tx = x, ty = y;
    addEventListener('mousemove', e => { tx = e.clientX; ty = e.clientY; });
    (function raf(){
      x += (tx - x) * .12; y += (ty - y) * .12;
      glow.style.transform = `translate(${x}px, ${y}px) translate(-50%,-50%)`;
      requestAnimationFrame(raf);
    })();
  }

  // ===== Particles canvas =====
  const canvas = document.getElementById('particles');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let w, h, particles;
    const COUNT = Math.min(80, Math.floor((innerWidth * innerHeight) / 22000));
    function resize() {
      w = canvas.width = innerWidth * devicePixelRatio;
      h = canvas.height = innerHeight * devicePixelRatio;
      canvas.style.width = innerWidth + 'px';
      canvas.style.height = innerHeight + 'px';
    }
    function init() {
      particles = Array.from({ length: COUNT }, () => ({
        x: Math.random() * w, y: Math.random() * h,
        vx: (Math.random() - .5) * .25 * devicePixelRatio,
        vy: (Math.random() - .5) * .25 * devicePixelRatio,
        r: (Math.random() * 1.4 + .4) * devicePixelRatio,
      }));
    }
    function tick() {
      ctx.clearRect(0, 0, w, h);
      // links
      for (let i = 0; i < particles.length; i++) {
        const a = particles[i];
        a.x += a.vx; a.y += a.vy;
        if (a.x < 0 || a.x > w) a.vx *= -1;
        if (a.y < 0 || a.y > h) a.vy *= -1;
        for (let j = i + 1; j < particles.length; j++) {
          const b = particles[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const d2 = dx * dx + dy * dy;
          const max = 140 * devicePixelRatio;
          if (d2 < max * max) {
            const o = 1 - Math.sqrt(d2) / max;
            ctx.strokeStyle = `rgba(124,243,255,${o * .12})`;
            ctx.lineWidth = devicePixelRatio * .6;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
        ctx.fillStyle = 'rgba(180,210,255,.6)';
        ctx.beginPath(); ctx.arc(a.x, a.y, a.r, 0, Math.PI * 2); ctx.fill();
      }
      requestAnimationFrame(tick);
    }
    resize(); init(); tick();
    addEventListener('resize', () => { resize(); init(); });
  }

  // ===== Identity rotator =====
  const rotator = document.querySelector('.rotator');
  if (rotator) {
    const roles = [
      'Founder & Managing Director',
      'AI Product Architect',
      'Technology Visionary',
      'Software Systems Builder',
      'Digital Ecosystem Engineer',
      'Innovation Strategist',
      'Enterprise SaaS Architect',
      'Blockchain Ecosystem Researcher',
      'AI Infrastructure Builder',
      'Healthcare SaaS Innovator',
    ];
    let i = 0, j = 0, del = false;
    function type() {
      const word = roles[i];
      rotator.textContent = word.slice(0, j);
      if (!del && j < word.length) { j++; setTimeout(type, 55); }
      else if (del && j > 0) { j--; setTimeout(type, 28); }
      else {
        del = !del;
        if (!del) i = (i + 1) % roles.length;
        setTimeout(type, del ? 1600 : 380);
      }
    }
    type();
  }

  // ===== Reveal on scroll =====
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('in');
        // counters
        e.target.querySelectorAll('[data-count]').forEach(el => {
          if (el.dataset.done) return;
          el.dataset.done = '1';
          const target = +el.dataset.count;
          const dur = 1500, start = performance.now();
          const suffix = el.dataset.suffix || '';
          function step(t){
            const p = Math.min(1, (t - start) / dur);
            const eased = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.floor(target * eased).toLocaleString() + suffix;
            if (p < 1) requestAnimationFrame(step);
          }
          requestAnimationFrame(step);
          const bar = el.parentElement.querySelector('.bar i');
          if (bar) bar.style.width = '100%';
        });
        io.unobserve(e.target);
      }
    });
  }, { threshold: .12, rootMargin: '0px 0px -60px 0px' });
  document.querySelectorAll('.reveal,.reveal-stagger').forEach(el => io.observe(el));

  // ===== Active nav link on scroll =====
  const navLinks = document.querySelectorAll('.nav-links a[href^="#"]');
  if (navLinks.length) {
    const sections = [...navLinks].map(a => document.querySelector(a.getAttribute('href'))).filter(Boolean);
    addEventListener('scroll', () => {
      const y = scrollY + 120;
      let active = sections[0]?.id;
      sections.forEach(s => { if (s.offsetTop <= y) active = s.id; });
      navLinks.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + active));
    }, { passive: true });
  }

  // ===== Contact form (mailto fallback, no backend) =====
  const form = document.querySelector('form.contact-form');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const d = new FormData(form);
      const subject = encodeURIComponent(`[Portfolio] ${d.get('topic') || 'Inquiry'} — ${d.get('name')}`);
      const body = encodeURIComponent(`Name: ${d.get('name')}\nEmail: ${d.get('email')}\nCompany: ${d.get('company') || '—'}\n\n${d.get('message')}`);
      location.href = `mailto:cto@sayanjalinexus.com?subject=${subject}&body=${body}`;
    });
  }
})();
